import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Dax Trade",
  description: "Dax Trade — connect securely to Deriv",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
