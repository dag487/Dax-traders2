import { cookies } from "next/headers";
import Link from "next/link";

export default async function ConnectedPage() {
  const jar = await cookies();
  const connected = Boolean(jar.get("dax_deriv_access")?.value);
  return (
    <main className="page">
      <nav className="nav"><div className="brand"><span className="brandMark">D</span> DAX TRADE</div></nav>
      <section className="hero result">
        <div className="resultIcon">{connected ? "✓" : "!"}</div>
        <div className="eyebrow">DERIV CONNECTION</div>
        <h1>{connected ? "Authorization complete." : "Not connected yet."}</h1>
        <p className="intro">
          {connected
            ? "Deriv returned an authorization successfully. This starter stores the short-lived access token in an HTTP-only cookie. Account details and trading controls have not been enabled yet."
            : "No active Dax Trade authorization was found. Start again from the home page and approve access on Deriv."}
        </p>
        <Link className="button" href="/">Back to Dax Trade <span>→</span></Link>
        <p className="warning">For security, never share tokens or screenshots that show account credentials. Revoke access in Deriv if you no longer trust this site.</p>
      </section>
    </main>
  );
}
