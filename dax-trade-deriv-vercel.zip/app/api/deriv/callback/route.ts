import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const url = new URL(request.url);
  const error = url.searchParams.get("error");
  if (error) return NextResponse.redirect(new URL("/error?reason=denied", request.url));

  const code = url.searchParams.get("code");
  const returnedState = url.searchParams.get("state");
  const savedState = request.cookies.get("dax_oauth_state")?.value;
  const verifier = request.cookies.get("dax_oauth_verifier")?.value;
  const clientId = process.env.DERIV_CLIENT_ID;
  const redirectUri = process.env.DERIV_REDIRECT_URI;

  if (!code || !returnedState || !savedState || returnedState !== savedState || !verifier) {
    return NextResponse.redirect(new URL("/error?reason=state", request.url));
  }
  if (!clientId || !redirectUri) {
    return NextResponse.redirect(new URL("/error?reason=config", request.url));
  }

  try {
    const body = new URLSearchParams({
      grant_type: "authorization_code",
      client_id: clientId,
      code,
      code_verifier: verifier,
      redirect_uri: redirectUri,
    });
    const tokenResponse = await fetch("https://auth.deriv.com/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
      cache: "no-store",
    });
    if (!tokenResponse.ok) {
      return NextResponse.redirect(new URL("/error?reason=exchange", request.url));
    }
    const tokenData = await tokenResponse.json() as { access_token?: string; expires_in?: number };
    if (!tokenData.access_token) {
      return NextResponse.redirect(new URL("/error?reason=exchange", request.url));
    }

    const response = NextResponse.redirect(new URL("/connected", request.url));
    response.cookies.set("dax_deriv_access", tokenData.access_token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: Math.min(Math.max(tokenData.expires_in || 3600, 60), 3600),
    });
    response.cookies.set("dax_oauth_state", "", { httpOnly: true, path: "/", maxAge: 0 });
    response.cookies.set("dax_oauth_verifier", "", { httpOnly: true, path: "/", maxAge: 0 });
    return response;
  } catch {
    return NextResponse.redirect(new URL("/error?reason=exchange", request.url));
  }
}
