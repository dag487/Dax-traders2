import { createHash, randomBytes } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

function base64url(buffer: Buffer) {
  return buffer.toString("base64").replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

export async function GET(request: NextRequest) {
  const clientId = process.env.DERIV_CLIENT_ID;
  const redirectUri = process.env.DERIV_REDIRECT_URI;
  if (!clientId || !redirectUri) {
    return NextResponse.redirect(new URL("/error?reason=config", request.url));
  }

  const verifier = base64url(randomBytes(48));
  const challenge = base64url(createHash("sha256").update(verifier).digest());
  const state = base64url(randomBytes(24));

  const auth = new URL("https://auth.deriv.com/oauth2/auth");
  auth.searchParams.set("response_type", "code");
  auth.searchParams.set("client_id", clientId);
  auth.searchParams.set("redirect_uri", redirectUri);
  auth.searchParams.set("scope", "trade");
  auth.searchParams.set("state", state);
  auth.searchParams.set("code_challenge", challenge);
  auth.searchParams.set("code_challenge_method", "S256");

  const response = NextResponse.redirect(auth);
  const secure = process.env.NODE_ENV === "production";
  response.cookies.set("dax_oauth_state", state, {
    httpOnly: true, secure, sameSite: "lax", path: "/", maxAge: 600
  });
  response.cookies.set("dax_oauth_verifier", verifier, {
    httpOnly: true, secure, sameSite: "lax", path: "/", maxAge: 600
  });
  return response;
}
