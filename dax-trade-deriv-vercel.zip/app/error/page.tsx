import Link from "next/link";
export default async function ErrorPage({ searchParams }: { searchParams: Promise<{ reason?: string }> }) {
  const { reason } = await searchParams;
  const messages: Record<string, string> = {
    config: "The site owner has not configured the Deriv client ID and callback URL in Vercel.",
    state: "The security check failed. Please restart the connection from Dax Trade.",
    exchange: "Deriv could not complete authorization. Please restart and approve access on Deriv.",
    denied: "Authorization was cancelled or denied on Deriv."
  };
  return <main className="page"><section className="hero result"><div className="resultIcon">!</div><div className="eyebrow">CONNECTION ISSUE</div><h1>We couldn't connect.</h1><p className="intro">{messages[reason || ""] || "Something went wrong during authorization. Please try again."}</p><Link className="button" href="/">Try again <span>→</span></Link></section></main>;
}
