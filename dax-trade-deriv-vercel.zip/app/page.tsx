export default function Home() {
  return (
    <main className="page">
      <nav className="nav">
        <div className="brand"><span className="brandMark">D</span> DAX TRADE</div>
        <span className="status"><span className="dot" /> Secure connection setup</span>
      </nav>
      <section className="hero">
        <div className="eyebrow">YOUR TRADING WORKSPACE</div>
        <h1>Trade with clarity.<br /><span>Stay in control.</span></h1>
        <p className="intro">
          Connect your Deriv account securely to begin building your Dax Trade dashboard.
          You will sign in on Deriv itself; Dax Trade never asks for your Deriv password.
        </p>
        <div className="panel">
          <div className="panelIcon">↗</div>
          <div className="panelText">
            <h2>Connect Deriv account</h2>
            <p>Authorize access on Deriv. Review the permissions shown before approving.</p>
          </div>
          <a className="button" href="/api/deriv/login">Connect Deriv <span>→</span></a>
        </div>
        <div className="features">
          <div><span className="featureIcon">01</span><b>Secure sign-in</b><p>OAuth authorization flow.</p></div>
          <div><span className="featureIcon">02</span><b>Your permission</b><p>You approve access on Deriv.</p></div>
          <div><span className="featureIcon">03</span><b>Build gradually</b><p>Start with connection status before live trading.</p></div>
        </div>
        <p className="warning"><b>Real-money safety:</b> This starter establishes sign-in only. It does not place trades or guarantee profits. Test with a demo account first.</p>
      </section>
      <footer>DAX TRADE <span>Independent project · Not an official Deriv product</span></footer>
    </main>
  );
}
